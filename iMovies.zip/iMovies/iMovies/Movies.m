//
//  Movies.m
//  iMovies
//
//  Created by Badri on 25/07/14.
//  Copyright (c) 2014 Badri. All rights reserved.
//

#import "Movies.h"


@implementation Movies

@dynamic movieName;
@dynamic movieDesc;
@dynamic genre;
@dynamic cast;
@dynamic showTimes;
@dynamic price;

@end
