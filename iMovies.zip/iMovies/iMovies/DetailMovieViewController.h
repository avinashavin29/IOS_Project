//
//  DetailMovieViewController.h
//  iMovies
//
//  Created by Badri on 25/07/14.
//  Copyright (c) 2014 Badri. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Movies.h"

@interface DetailMovieViewController : UIViewController

@property (nonatomic , retain) Movies *movies;
@end
